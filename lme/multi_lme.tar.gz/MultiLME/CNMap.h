#ifndef CNMAP
#define CNMAP
typedef struct
{
	int num_clusters;
	int num_nodes;
	int* node_cluster_map;
	int** cluster_node_map;
	int* num_nodes_for_each_cluster;
}
CNMap;

typedef struct
{
	int num_clusters;
	int num_nodes;
	int* cluster_node_map;
	int** node_cluster_map;
	int* num_clusters_on_each_node;
}
NCMap;

void free_CNMap(CNMap cnm);
CNMap create_CNmap(int num_clusters, int num_nodes, int* cluster_size_array, int* nnz_array);
void rr_assign(int n, int m, double* scores,  int* num_assigned);
void free_NCMap(NCMap ncm);
NCMap create_NCmap(int num_clusters, int num_nodes, int* cluster_size_array, int* nnz_array);

#endif
