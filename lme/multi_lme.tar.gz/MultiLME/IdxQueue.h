#ifndef IDX_QUEUE
#define IDX_QUEUE

typedef struct qelem
{
    int idx;
    struct qelem* pnext;
}
QELEM;

typedef struct
{
    int length;
    QELEM* head;
    QELEM* tail;
}
IDXQUEUE;

void init_idx_queue(IDXQUEUE* piq);
void free_idx_queue(IDXQUEUE* piq);
int exist_in_idx_queue(int q, IDXQUEUE* piq);
void push_in_idx_queue(int q, IDXQUEUE* piq);
int pop_from_idx_queue(IDXQUEUE* piq);
void delete_from_idx_queue(IDXQUEUE* piq, int idx_to_delete);

#endif
